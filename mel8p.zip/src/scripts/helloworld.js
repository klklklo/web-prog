/* helloWold() {
    console.log('hello from module');
} */

export function helloWorld() {
    console.log(` from module `);
}
export let phrase = "Hello"
/* export default {
    helloWorld( { phrase } ) {
        let name = name;
        let phraseToSay = phrase 
            ? phrase 
            : this.phrase
        console.log(`${phraseToSay } from module ${name}`);
    },
    phrase,
    hw: helloWorld
} */
