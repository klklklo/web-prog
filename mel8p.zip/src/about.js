import about from './about.html'
import './css/about.css'
import '@fortawesome/fontawesome-free/js/all'
import './images/yoda.jpg'

function add(a,b) {
    a = a * 2;
    b = b - 2;
    return a + b;
}
var result = add(10, 20);
console.log('about');
