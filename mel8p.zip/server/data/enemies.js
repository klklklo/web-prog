const enemies = [
    {
        id: 1,
        image: '/images/wolf.jpg',
        name: 'Волк'
    },
    {
        id: 2,
        image: '/images/fox.jpg',
        name: 'Лиса'
    },
    {
        id: 3,
        image: '/images/ferret.jpg',
        name: 'Хорек'
    },
    {
        id: 4,
        image: '/images/kite.jpg',
        name: 'Коршун'
    },
    {
        id: 5,
        image: '/images/owl.jpg',
        name: 'Сова'
    },
    {
        id: 6,
        image: '/images/snake.jpg',
        name: 'Гадюка'
    }
]
module.exports = enemies;